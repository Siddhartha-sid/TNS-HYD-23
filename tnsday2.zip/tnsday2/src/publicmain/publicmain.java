package publicmain;

public class publicmain 
{
	int a=30;
	public static void main(String[] args) 
	{
		publicmain obj=new publicmain();
		System.out.println(obj.a);
		
	}
}