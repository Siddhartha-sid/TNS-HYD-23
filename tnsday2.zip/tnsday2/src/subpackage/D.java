package subpackage;

public class D 
{
	public void msg()
	{
		System.out.println("hello D");
	}
}
