package protect2;
import protect.*;

	

	public class protect2 extends protect 
	{

		public static void main(String[] args) 
		{
			protect2 n2 = new protect2();
			System.out.println(n2.str);
			
		}

	}


