package privatemain;

public class privatemain 
{
	private void display()
	{
		System.out.println("hello world");
	}
	public static void main(String[] args) 
	{
		privatemain obj=new privatemain();
		obj.display();		
		
	}

}
