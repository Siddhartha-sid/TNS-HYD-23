package protect;

public class protect 
{
	
		protected String str = "This is a Protected member.";
		
		public static void main(String[] args) {
			protect n1 = new protect();
			
			System.out.println(n1.str);
		}

	

}
