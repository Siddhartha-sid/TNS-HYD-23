package Approach1;

public class approach1 
{
	int a=10;
	static int b=20;
	int display()
	{
		return 10;
	}
	static void display1()
	{
		System.out.println(20);
	}
	public static void main(String[] args) 
	{
		int c=30;
		System.out.println(c);
		approach1 obj=new approach1();
		System.out.println(obj.a);
		System.out.println(approach1.b);
		obj.display();
		approach1.display1();
	}
}
