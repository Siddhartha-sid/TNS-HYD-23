package defaultmain;

public class defaultmain 
{
		void display()
		{
			System.out.println("hello world");
		}
		public static void main(String[] args) 
		{
			defaultmain obj=new defaultmain();
			obj.display();		
			
		}
}
